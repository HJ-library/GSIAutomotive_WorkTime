import math
import calendar
import sqlite3
from datetime import datetime, timedelta
import pandas as pd
from database import get_connection

def get_users():
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT id, name FROM users ORDER BY name')
    users = c.fetchall()
    conn.close()
    return [{"id": u[0], "name": u[1]} for u in users]

def add_user(name):
    conn = get_connection()
    c = conn.cursor()
    try:
        c.execute('INSERT INTO users (name) VALUES (?)', (name,))
        conn.commit()
        user_id = c.lastrowid
        status = "success"
        msg = "User added"
    except sqlite3.IntegrityError:
        user_id = None
        status = "error"
        msg = "User already exists"
    conn.close()
    return {"status": status, "user_id": user_id, "message": msg}

def calculate_work_time(clock_in_str, clock_out_str, non_work_minutes):
    if not clock_in_str or not clock_out_str:
        return 0, 0
        
    fmt = "%H:%M"
    try:
        t_in = datetime.strptime(clock_in_str, fmt)
        t_out = datetime.strptime(clock_out_str, fmt)
    except ValueError:
        return 0, 0
        
    if t_out < t_in:
        t_out += timedelta(days=1)
        
    total_duration_minutes = int((t_out - t_in).total_seconds() / 60)
    target_duration = total_duration_minutes - non_work_minutes
    
    if target_duration <= 0:
        return 0, 0
        
    W = target_duration
    breaks = 0
    while W >= 240 * (breaks + 1):
        W -= 30
        breaks += 1
        
    return W, breaks * 30

def save_work_log(user_id, date_str, log_type, clock_in, clock_out, non_work_time, overtime_used=0):
    if not user_id:
        return
        
    conn = get_connection()
    c = conn.cursor()
    
    if log_type in ['holiday', 'annual_leave']:
        work_minutes = 8 * 60
        break_minutes = 0
        clock_in = '08:30'
        clock_out = '17:30'
        non_work_time = 0
    elif log_type in ['morning_half', 'afternoon_half']:
        work_minutes = 4 * 60
        break_minutes = 0
        non_work_time = 0
        if log_type == 'morning_half':
            clock_in = '08:30'
            clock_out = '12:30'
        else:
            clock_in = '13:30'
            clock_out = '17:30'
    else:
        work_minutes, break_minutes = calculate_work_time(clock_in, clock_out, non_work_time)
        
    c.execute('''
        INSERT OR REPLACE INTO work_logs 
        (user_id, date, type, clock_in, clock_out, non_work_time, break_time, work_time, overtime_earned, overtime_used)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    ''', (user_id, date_str, log_type, clock_in, clock_out, non_work_time, break_minutes, work_minutes, overtime_used))
    conn.commit()
    conn.close()
    
    recalculate_monthly_overtime(user_id, date_str[:7])

def recalculate_monthly_overtime(user_id, month_str):
    conn = get_connection()
    c = conn.cursor()
    
    c.execute('SELECT date, work_time, type FROM work_logs WHERE user_id = ? AND date LIKE ? ORDER BY date', (user_id, month_str + '%'))
    logs = c.fetchall()
    
    accumulated_raw_overtime = 0
    
    for row in logs:
        date_str = row[0]
        work_time = row[1]
        log_type = row[2]
        
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        is_weekend = dt.weekday() >= 5
        
        raw_earned = 0
        if is_weekend:
            raw_earned = work_time
        else:
            if work_time > 480:
                raw_earned = work_time - 480
                
        earned = 0
        if raw_earned > 0:
            available_1x = max(0, 1200 - accumulated_raw_overtime)
            
            if raw_earned <= available_1x:
                earned = raw_earned
            else:
                portion_1x = available_1x
                portion_15x = raw_earned - available_1x
                earned = portion_1x + int(portion_15x * 1.5)
                
            accumulated_raw_overtime += raw_earned
            
        c.execute('UPDATE work_logs SET overtime_earned = ? WHERE user_id = ? AND date = ?', (earned, user_id, date_str))
        
    conn.commit()
    conn.close()

def get_work_logs(user_id, start_date_str, end_date_str):
    if not user_id:
        return []
    conn = get_connection()
    df = pd.read_sql_query('SELECT * FROM work_logs WHERE user_id = ? AND date >= ? AND date <= ? ORDER BY date', conn, params=(user_id, start_date_str, end_date_str))
    conn.close()
    return df.to_dict('records')

def get_monthly_summary(user_id, month_str):
    if not user_id:
        return {"carry_over": 0, "curr_earned": 0, "curr_used": 0, "expiring_soon": 0, "total_remaining": 0}
        
    conn = get_connection()
    c = conn.cursor()
    
    c.execute('SELECT SUM(overtime_earned), SUM(overtime_used) FROM work_logs WHERE user_id = ? AND date < ?', (user_id, month_str + '-01'))
    row = c.fetchone()
    prev_earned = row[0] or 0
    prev_used = row[1] or 0
    carry_over = max(0, prev_earned - prev_used)
    
    c.execute('SELECT SUM(overtime_earned), SUM(overtime_used) FROM work_logs WHERE user_id = ? AND date LIKE ?', (user_id, month_str + '%'))
    row2 = c.fetchone()
    curr_earned = row2[0] or 0
    curr_used = row2[1] or 0
    
    total_remaining = carry_over + curr_earned - curr_used
    expiring_soon = carry_over
    
    conn.close()
    
    return {
        "carry_over": carry_over,
        "curr_earned": curr_earned,
        "curr_used": curr_used,
        "expiring_soon": expiring_soon,
        "total_remaining": total_remaining
    }

def get_weekly_work_time(user_id, start_date_str, end_date_str):
    if not user_id:
        return 0
    conn = get_connection()
    c = conn.cursor()
    c.execute('SELECT SUM(work_time) FROM work_logs WHERE user_id = ? AND date >= ? AND date <= ?', (user_id, start_date_str, end_date_str))
    row = c.fetchone()
    conn.close()
    return row[0] or 0

def export_monthly_excel(user_id, month_str, filepath):
    if not user_id:
        return False
        
    conn = get_connection()
    # Get user name for export
    c = conn.cursor()
    c.execute('SELECT name FROM users WHERE id = ?', (user_id,))
    u_row = c.fetchone()
    user_name = u_row[0] if u_row else "Unknown"
    
    df = pd.read_sql_query('SELECT * FROM work_logs WHERE user_id = ? AND date LIKE ? ORDER BY date', conn, params=(user_id, month_str + '%',))
    conn.close()
    
    if df.empty:
        return False
        
    def mins_to_hm(mins):
        h = mins // 60
        m = mins % 60
        return f"{int(h):02d}:{int(m):02d}"
        
    # Formatting
    df['non_work_time'] = df['non_work_time'].apply(mins_to_hm)
    df['break_time'] = df['break_time'].apply(mins_to_hm)
    df['work_time'] = df['work_time'].apply(mins_to_hm)
    
    # We need to preserve overtime_earned raw integer to highlight, but also output string
    df['overtime_earned_hm'] = df['overtime_earned'].apply(mins_to_hm)
    df['overtime_used_hm'] = df['overtime_used'].apply(mins_to_hm)
    
    # Reorder/rename columns for the excel
    cols = ['date', 'type', 'clock_in', 'clock_out', 'non_work_time', 'break_time', 'work_time', 'overtime_earned_hm', 'overtime_used_hm']
    out_df = df[cols].copy()
    out_df.columns = ['일자', '근무형태', '출근', '퇴근', '비근무시간', '휴게시간', '실근무시간', '발생연장근로', '사용연장근로']
    
    # Save basic dataframe to excel first
    out_df.to_excel(filepath, index=False)
    
    # Post-process with openpyxl to add styles
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import PatternFill
        
        wb = load_workbook(filepath)
        ws = wb.active
        
        yellow_fill = PatternFill(start_color="FEF08A", end_color="FEF08A", fill_type="solid")
        
        # openpyxl is 1-indexed. Row 1 is header. Data starts at row 2.
        for r_idx, row in enumerate(df.itertuples(), start=2):
            # 'overtime_earned' is the actual integer column in original df
            if getattr(row, 'overtime_earned', 0) > 0:
                for c_idx in range(1, len(out_df.columns) + 1):
                    ws.cell(row=r_idx, column=c_idx).fill = yellow_fill
                    
        wb.save(filepath)
    except Exception as e:
        print("Excel styling failed:", e)
        
    return True

def import_excel(filepath):
    return False, "Not implemented yet"

def get_vault_details(user_id):
    return []

def extend_overtime(user_id, vault_id, admin_pw):
    return False, "Not implemented yet"

def auto_fill_missing_days(user_id):
    pass
