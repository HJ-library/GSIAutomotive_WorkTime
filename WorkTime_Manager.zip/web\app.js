document.addEventListener("DOMContentLoaded", () => {
    // Navigation
    const navLinks = document.querySelectorAll(".nav-links li");
    const views = document.querySelectorAll(".view");

    navLinks.forEach(link => {
        link.addEventListener("click", () => {
            navLinks.forEach(n => n.classList.remove("active"));
            link.classList.add("active");
            
            const targetId = link.getAttribute("data-target");
            views.forEach(v => v.classList.remove("active"));
            document.getElementById(targetId).classList.add("active");
            
            if (targetId === "dashboard") {
                loadDashboardData();
            } else if (targetId === "schedule") {
                initScheduleView();
            } else if (targetId === "entry") {
                loadWeeklyEntryData();
            } else if (targetId === "overtime") {
                loadVaultData();
            }
        });
    });

    // User Management
    const userSelect = document.getElementById("user-select");
    const btnAddUser = document.getElementById("btn-add-user");
    
    async function loadUsers() {
        if (!window.pywebview) return;
        try {
            const users = await window.pywebview.api.get_users();
            userSelect.innerHTML = '';
            if (users.length === 0) {
                userSelect.innerHTML = '<option value="">사용자 없음</option>';
            } else {
                users.forEach(u => {
                    const opt = document.createElement('option');
                    opt.value = u.id;
                    opt.innerText = u.name;
                    userSelect.appendChild(opt);
                });
            }
        } catch(e) {
            console.error("Failed to load users", e);
        }
    }
    
    btnAddUser.addEventListener("click", async () => {
        const name = prompt("추가할 사용자 이름을 입력하세요:");
        if (name && name.trim()) {
            try {
                const res = await window.pywebview.api.add_user(name.trim());
                if (res.status === 'success') {
                    showToast("사용자가 추가되었습니다.", "success");
                    await loadUsers();
                    userSelect.value = res.user_id;
                    reloadAllData();
                } else {
                    showToast("오류: " + res.message, "error");
                }
            } catch(e) {}
        }
    });
    
    userSelect.addEventListener("change", reloadAllData);
    
    function reloadAllData() {
        loadDashboardData();
        loadWeeklyEntryData();
        loadVaultData();
        if (document.getElementById("schedule").classList.contains("active")) {
            loadScheduleData();
        }
    }

    // Time Entry Defaults & Logic
    const entryDate = document.getElementById("entry-date");
    const entryType = document.getElementById("entry-type");
    const clockIn = document.getElementById("clock-in");
    const clockOut = document.getElementById("clock-out");
    const nonWork = document.getElementById("non-work");
    const btnMinus30 = document.getElementById("btn-minus-30");
    const btnPlus30 = document.getElementById("btn-plus-30");
    const timeInputsContainer = document.getElementById("time-inputs-container");

    // Default to today
    const today = new Date();
    entryDate.value = today.toISOString().split('T')[0];

    function applyDefaults() {
        const type = entryType.value;
        if (type === "normal") {
            clockIn.value = "08:30";
            clockOut.value = "17:30";
            timeInputsContainer.style.display = "grid";
            nonWork.value = 0;
        } else if (type === "morning_half") {
            clockIn.value = "08:30";
            clockOut.value = "12:30";
            timeInputsContainer.style.display = "grid";
            nonWork.value = 0;
        } else if (type === "afternoon_half") {
            clockIn.value = "13:30";
            clockOut.value = "17:30";
            timeInputsContainer.style.display = "grid";
            nonWork.value = 0;
        } else if (type === "holiday" || type === "annual_leave") {
            timeInputsContainer.style.display = "none";
        }
    }

    entryType.addEventListener("change", applyDefaults);
    entryDate.addEventListener("change", applyDefaults);

    btnMinus30.addEventListener("click", () => {
        let val = parseInt(nonWork.value) || 0;
        if (val >= 30) nonWork.value = val - 30;
    });

    btnPlus30.addEventListener("click", () => {
        let val = parseInt(nonWork.value) || 0;
        nonWork.value = val + 30;
    });

    document.getElementById("btn-save-log").addEventListener("click", async () => {
        if (!window.pywebview) {
            showToast("앱 초기화 중입니다. 잠시 후 다시 시도해주세요.", "warning");
            return;
        }
        
        const userId = userSelect.value;
        if (!userId) {
            showToast("사용자를 먼저 추가/선택해주세요.", "warning");
            return;
        }
        
        const data = {
            user_id: parseInt(userId),
            date: entryDate.value,
            type: entryType.value,
            clock_in: clockIn.value,
            clock_out: clockOut.value,
            non_work_time: nonWork.value,
            overtime_used: document.getElementById("overtime-used").value || 0
        };

        try {
            const res = await window.pywebview.api.save_log(data);
            if (res.status === "success") {
                showToast("저장되었습니다.", "success");
                reloadAllData();
            }
        } catch (err) {
            showToast("저장 실패", "error");
        }
    });

    entryDate.addEventListener("change", () => {
        applyDefaults();
        loadWeeklyEntryData();
    });

    async function loadWeeklyEntryData() {
        if (!window.pywebview) return;
        const d = new Date(entryDate.value);
        if(isNaN(d.getTime())) return;
        
        let day = d.getDay();
        let diffToMonday = d.getDate() - day + (day === 0 ? -6 : 1);
        let monday = new Date(d.setDate(diffToMonday));
        let sunday = new Date(monday.getTime() + 6 * 24 * 60 * 60 * 1000);
        
        const startStr = monday.toISOString().split('T')[0];
        const endStr = sunday.toISOString().split('T')[0];
        
        const userId = userSelect.value;
        if (!userId) {
            const weeklyBody = document.getElementById("weekly-body");
            if(weeklyBody) weeklyBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 1rem;">사용자를 선택해주세요.</td></tr>';
            return;
        }

        try {
            const logs = await window.pywebview.api.get_logs(parseInt(userId), startStr, endStr);
            const weeklyBody = document.getElementById("weekly-body");
            weeklyBody.innerHTML = '';
            
            const typeNames = {"normal": "정상 근무", "morning_half": "오전 반차", "afternoon_half": "오후 반차", "holiday": "공휴일/연차"};
            const days = ["일", "월", "화", "수", "목", "금", "토"];
            
            logs.forEach(log => {
                const dateObj = new Date(log.date);
                const wMins = log.work_time;
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${log.date}</td>
                    <td>${days[dateObj.getDay()]}</td>
                    <td>${typeNames[log.type] || log.type}</td>
                    <td>${log.clock_in}</td>
                    <td>${log.clock_out}</td>
                    <td style="font-weight:bold;">${Math.floor(wMins/60)}h ${wMins%60}m</td>
                `;
                weeklyBody.appendChild(tr);
            });
            if (logs.length === 0) {
                weeklyBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 1rem;">기록이 없습니다.</td></tr>';
            }
        } catch(e) {}
    }

    // Dashboard Data
    const dashWeek = document.getElementById("dash-week");
    
    // Set current week for dashboard (e.g. "2026-W17")
    const getWeekString = (d) => {
        const date = new Date(d.getTime());
        date.setHours(0, 0, 0, 0);
        date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
        const week1 = new Date(date.getFullYear(), 0, 4);
        const weekNumber = 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
        return `${date.getFullYear()}-W${weekNumber.toString().padStart(2, '0')}`;
    };
    
    dashWeek.value = getWeekString(today);

    dashWeek.addEventListener("change", loadDashboardData);

    async function loadDashboardData() {
        if (!window.pywebview) return;
        
        // Convert week string to a date in that week
        const weekVal = dashWeek.value; // "YYYY-Www"
        if(!weekVal) return;
        const [year, week] = weekVal.split('-W');
        // Simple approx: get to a day in that week
        const simpleDate = new Date(year, 0, 1 + (week - 1) * 7);
        const dateStr = simpleDate.toISOString().split('T')[0];
        
        const userId = userSelect.value;
        if (!userId) return;

        try {
            const res = await window.pywebview.api.get_weekly_summary(parseInt(userId), dateStr);
            const totalMins = res.total_minutes;
            const overtimeMins = res.overtime_minutes || 0;
            const hours = Math.floor(totalMins / 60);
            const mins = totalMins % 60;
            
            document.getElementById("weekly-hours").innerText = `${hours}h ${mins}m`;
            document.getElementById("weekly-overtime").innerText = `${Math.floor(overtimeMins/60)}h ${overtimeMins%60}m`;
            
            const progress = document.getElementById("weekly-progress");
            const maxMins = 52 * 60;
            let percent = (totalMins / maxMins) * 100;
            if (percent > 100) percent = 100;
            progress.style.width = `${percent}%`;
            
            if (hours >= 46 && hours < 52) {
                progress.style.background = "linear-gradient(90deg, #f59e0b, #ef4444)";
                showToast("경고: 주 46시간을 초과했습니다.", "warning");
            } else if (hours >= 52) {
                progress.style.background = "#ef4444";
                showToast("주 52시간 제한에 도달했습니다!", "error");
            } else {
                progress.style.background = "linear-gradient(90deg, #3b82f6, #8b5cf6)";
            }
            
        } catch(e) {
            console.error(e);
        }
    }

    // Schedule View Logic
    const scheduleMonth = document.getElementById("schedule-month");
    const scheduleBody = document.getElementById("schedule-body");

    function initScheduleView() {
        if (!scheduleMonth.value) {
            scheduleMonth.value = today.toISOString().substring(0, 7);
        }
        loadScheduleData();
    }

    scheduleMonth.addEventListener("change", loadScheduleData);

    function formatHm(mins) {
        if (!mins) return "0h 0m";
        return `${Math.floor(mins/60)}h ${mins%60}m`;
    }

    async function loadScheduleData() {
        if (!window.pywebview) return;
        
        const monthVal = scheduleMonth.value;
        if(!monthVal) return;
        const [year, month] = monthVal.split('-');
        const startStr = `${year}-${month}-01`;
        let nextMonth = new Date(year, month, 1);
        let lastDay = new Date(nextMonth.getTime() - 1);
        const endStr = lastDay.toISOString().split('T')[0];
        
        const userId = userSelect.value;
        if (!userId) {
            scheduleBody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 2rem;">사용자를 선택해주세요.</td></tr>';
            return;
        }
        
        try {
            // Fetch stats
            const stats = await window.pywebview.api.get_monthly_summary(parseInt(userId), monthVal);
            document.getElementById("stat-carry").innerText = formatHm(stats.carry_over);
            document.getElementById("stat-earned").innerText = formatHm(stats.curr_earned);
            document.getElementById("stat-used").innerText = formatHm(stats.curr_used);
            document.getElementById("stat-expire").innerText = formatHm(stats.expiring_soon);
            document.getElementById("stat-total").innerText = formatHm(stats.total_remaining);
        
            // Fetch logs
            const logs = await window.pywebview.api.get_logs(parseInt(userId), startStr, endStr);
            scheduleBody.innerHTML = '';
            
            const days = ["일", "월", "화", "수", "목", "금", "토"];
            
            logs.forEach(log => {
                const dateObj = new Date(log.date);
                const dayName = days[dateObj.getDay()];
                
                const tr = document.createElement("tr");
                if (log.overtime_earned > 0) {
                    tr.classList.add("highlight-overtime");
                }
                tr.innerHTML = `
                    <td>${log.date}</td>
                    <td>${dayName}</td>
                    <td>${log.clock_in} ~ ${log.clock_out}</td>
                    <td>${log.non_work_time}m / ${log.break_time}m</td>
                    <td style="font-weight:bold;">${formatHm(log.work_time)}</td>
                    <td style="color:var(--accent-color); font-weight:bold;">${log.overtime_earned ? formatHm(log.overtime_earned) : '-'}</td>
                    <td style="color:var(--warning); font-weight:bold;">${log.overtime_used ? formatHm(log.overtime_used) : '-'}</td>
                `;
                scheduleBody.appendChild(tr);
            });
            
            if (logs.length === 0) {
                scheduleBody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 2rem;">기록이 없습니다.</td></tr>';
            }
        } catch(e) {
            console.error(e);
        }
    }

    // Export
    const exportMonth = document.getElementById("export-month");
    exportMonth.value = today.toISOString().substring(0, 7);
    
    document.getElementById("btn-export").addEventListener("click", async () => {
        if (!window.pywebview) return;
        const userId = userSelect.value;
        if (!userId) {
            showToast("사용자를 먼저 추가/선택해주세요.", "warning");
            return;
        }
        
        const month = exportMonth.value;
        const defaultFilename = `WorkTime_${month}.xlsx`;
        
        try {
            const savePath = await window.pywebview.api.save_file_dialog(defaultFilename);
            if (savePath) {
                const res = await window.pywebview.api.export_excel(parseInt(userId), month, savePath);
                if (res.status === "success") {
                    showToast("엑셀 파일이 저장되었습니다.", "success");
                } else {
                    showToast("저장 실패: " + res.message, "error");
                }
            }
        } catch(e) {
            showToast("오류 발생", "error");
        }
    });

    // Import
    document.getElementById("btn-import").addEventListener("click", async () => {
        if (!window.pywebview) return;
        try {
            const res = await window.pywebview.api.import_excel();
            if (res.status === "success") {
                showToast("성공적으로 Import 되었습니다.", "success");
                reloadAllData();
            } else {
                showToast("Import 실패: " + res.message, "error");
            }
        } catch(e) {
            showToast("오류 발생", "error");
        }
    });

    // Vault
    const vaultBody = document.getElementById("vault-body");
    async function loadVaultData() {
        if (!window.pywebview) return;
        const userId = userSelect.value;
        if (!userId) return;
        try {
            const vaults = await window.pywebview.api.get_vault_details(parseInt(userId));
            vaultBody.innerHTML = '';
            vaults.forEach(v => {
                const tr = document.createElement('tr');
                const remain = v.earned_minutes - v.used_minutes;
                const status = remain > 0 ? `<span style="color:var(--success)">사용가능</span>` : `<span style="color:var(--text-secondary)">소진됨</span>`;
                const btn = (remain > 0 && v.is_extended == 0) ? `<button class="btn" style="padding: 0.3rem 0.6rem; font-size:0.8rem;" onclick="openAdminModal(${v.id})">기한 연장</button>` : '';
                
                tr.innerHTML = `
                    <td>${v.date}</td>
                    <td>${formatHm(v.earned_minutes)}</td>
                    <td>${formatHm(v.used_minutes)}</td>
                    <td style="color:${v.is_extended ? 'var(--warning)' : 'inherit'}">${v.expires_at} ${v.is_extended ? '(연장됨)' : ''}</td>
                    <td>${status}</td>
                    <td>${btn}</td>
                `;
                vaultBody.appendChild(tr);
            });
            if (vaults.length === 0) {
                vaultBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 2rem;">내역이 없습니다.</td></tr>';
            }
        } catch(e) { console.error(e); }
    }

    // Modal
    window.openAdminModal = function(vaultId) {
        document.getElementById("modal-vault-id").value = vaultId;
        document.getElementById("admin-pw").value = '';
        document.getElementById("admin-modal").classList.add("show");
    };

    document.getElementById("btn-modal-cancel").addEventListener("click", () => {
        document.getElementById("admin-modal").classList.remove("show");
    });

    document.getElementById("btn-modal-confirm").addEventListener("click", async () => {
        const vaultId = document.getElementById("modal-vault-id").value;
        const pw = document.getElementById("admin-pw").value;
        if (!pw) return showToast("비밀번호를 입력하세요", "warning");
        
        try {
            const res = await window.pywebview.api.extend_overtime(vaultId, pw);
            if (res.status === "success") {
                showToast("유효기간이 연장되었습니다.", "success");
                document.getElementById("admin-modal").classList.remove("show");
                loadVaultData();
            } else {
                showToast(res.message, "error");
            }
        } catch(e) {
            showToast("오류 발생", "error");
        }
    });

    // Toast
    function showToast(message, type="success") {
        const toast = document.getElementById("toast");
        toast.className = "toast " + type;
        toast.innerText = message;
        toast.classList.add("show");
        setTimeout(() => {
            toast.classList.remove("show");
        }, 3000);
    }
    
    // Initial load when pywebview is ready
    window.addEventListener("pywebviewready", async function() {
        await loadUsers();
        try {
            const userId = userSelect.value;
            if (userId) {
                await window.pywebview.api.auto_fill_missing(parseInt(userId));
            }
        } catch(e) {}
        reloadAllData();
    });
});
