import webview
import json
import os
from datetime import datetime, timedelta
import logic
from database import init_db

class Api:
    def __init__(self):
        self.window = None

    def get_users(self):
        return logic.get_users()
        
    def add_user(self, name):
        return logic.add_user(name)

    def get_logs(self, user_id, start_date, end_date):
        return logic.get_work_logs(user_id, start_date, end_date)

    def save_log(self, data):
        user_id = data.get('user_id')
        date_str = data.get('date')
        log_type = data.get('type', 'normal')
        clock_in = data.get('clock_in', '')
        clock_out = data.get('clock_out', '')
        
        non_work_time_str = data.get('non_work_time', 0)
        non_work_time = int(non_work_time_str) if non_work_time_str else 0
        
        overtime_used_str = data.get('overtime_used', 0)
        overtime_used = int(overtime_used_str) if overtime_used_str else 0
        
        logic.save_work_log(user_id, date_str, log_type, clock_in, clock_out, non_work_time, overtime_used)
        return {"status": "success"}

    def get_weekly_summary(self, user_id, date_str):
        if not user_id:
            return {"start": "", "end": "", "total_minutes": 0}
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        days_to_monday = dt.weekday()
        start_dt = dt - timedelta(days=days_to_monday)
        end_dt = start_dt + timedelta(days=6)
        
        start_str = start_dt.strftime("%Y-%m-%d")
        end_str = end_dt.strftime("%Y-%m-%d")
        
        total_minutes = logic.get_weekly_work_time(user_id, start_str, end_str)
        return {
            "start": start_str,
            "end": end_str,
            "total_minutes": total_minutes
        }

    def get_monthly_summary(self, user_id, month_str):
        return logic.get_monthly_summary(user_id, month_str)

    def export_excel(self, user_id, month_str, filepath):
        try:
            success = logic.export_monthly_excel(user_id, month_str, filepath)
            if success:
                return {"status": "success"}
            return {"status": "error", "message": "No data found"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # A helper method to allow file dialog
    def save_file_dialog(self, default_filename):
        if self.window:
            result = self.window.create_file_dialog(
                webview.SAVE_DIALOG, 
                directory=os.getcwd(), 
                save_filename=default_filename
            )
            if result:
                return result[0]
        return None

    def import_excel(self):
        if self.window:
            result = self.window.create_file_dialog(
                webview.OPEN_DIALOG,
                allow_multiple=False,
                file_types=('Excel Files (*.xlsx;*.xls)', 'All Files (*.*)')
            )
            if result:
                filepath = result[0]
                success, msg = logic.import_excel(filepath)
                if success:
                    return {"status": "success"}
                else:
                    return {"status": "error", "message": msg}
        return {"status": "error", "message": "창 초기화 오류"}

    def get_vault_details(self, user_id):
        if not user_id:
            return []
        return logic.get_vault_details(user_id)

    def extend_overtime(self, user_id, vault_id, admin_pw):
        success, msg = logic.extend_overtime(user_id, vault_id, admin_pw)
        if success:
            return {"status": "success"}
        else:
            return {"status": "error", "message": msg}

    def auto_fill_missing(self, user_id):
        if user_id:
            logic.auto_fill_missing_days(user_id)
        return {"status": "success"}

if __name__ == '__main__':
    init_db()
    api = Api()
    
    # Resolve absolute path for HTML
    html_path = os.path.join(os.path.dirname(__file__), 'web', 'index.html')
    
    window = webview.create_window(
        '근태 관리 프로그램', 
        html_path, 
        js_api=api,
        width=1200,
        height=800,
        text_select=False
    )
    api.window = window
    webview.start()
